package br.edu.infnet.tp1java22abril;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class Main2Activity extends AppCompatActivity {

    String lstrNomeArq;
    File arq;
    String lstrlinha;
    private TextView txtLer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        txtLer = (TextView) findViewById(R.id.textViewId);

        String lstrNomeArq;
        File arq;
        String lstrlinha;

        Intent intent = getIntent();
        String parametro = (String) intent.getStringExtra("nomeAdd");
        txtLer.setText(parametro);


        try {

            lstrNomeArq = parametro;

            arq = new File(Environment.getExternalStorageDirectory(), lstrNomeArq);
            BufferedReader br = new BufferedReader(new FileReader(arq));


            while ((lstrlinha = br.readLine()) != null) {

                if (!txtLer.getText().toString().equals(""))
                {
                    txtLer.append("\n");
                }
                txtLer.append(lstrlinha);
            }

            Mensagem("Contato Carregado com sucesso!");

        } catch (Exception e) {

            Mensagem("Erro : " + e.getMessage());
        }


    }



    private void Mensagem(String msg)
    {
        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
    }


}



