package br.edu.infnet.tp1java22abril;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import android.os.Environment;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText nome;
    private EditText telefone;
    private EditText email;
    private EditText cidade;
    private Button botaoLimpar;
    private ArrayList<String> Arquivos = new ArrayList<String>();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) {

            } else {

                ActivityCompat.requestPermissions(MainActivity.this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},23);
            }
        }



        nome = (EditText) findViewById(R.id.nomeId);
        telefone = (EditText) findViewById(R.id.telefoneId);
        email = (EditText) findViewById(R.id.emailId);
        cidade = (EditText) findViewById(R.id.cidadeId);


        botaoLimpar = (Button) findViewById(R.id.btnLimparId);
        botaoLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                apagar();
            }
        });
    }






    public void apagar (){
        nome.setText(null);
        telefone.setText(null);
        email.setText(null);
        cidade.setText(null);
    }

    private void Mensagem (String msg) {
        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
    }

    public void click_salvar (View v){
        String nomeArq;
        File arq;
        byte[] dados;
        byte[] dados2;
        byte[] dados3;

        if (nome.getText().toString().isEmpty()){
            Toast.makeText(MainActivity.this, "Digite um nome", Toast.LENGTH_SHORT).show();
        } else if (telefone.getText().toString().isEmpty()){
            Toast.makeText(MainActivity.this, "Digite um telefone", Toast.LENGTH_SHORT).show();
        } else if (email.getText().toString().isEmpty()){
            Toast.makeText(MainActivity.this, "Digite um e-mail", Toast.LENGTH_SHORT).show();
        } else if (cidade.getText().toString().isEmpty()){
            Toast.makeText(MainActivity.this, "Digite uma cidade", Toast.LENGTH_SHORT).show();
        }

        try {
            nomeArq = nome.getText().toString();

            arq = new File(Environment.getExternalStorageDirectory(), nomeArq);
            FileOutputStream fos;


            dados = telefone.getText().toString().getBytes();
            dados2 = email.getText().toString().getBytes();
            dados3 = cidade.getText().toString().getBytes();

            fos = new FileOutputStream(arq);
            fos.write(dados);
            fos.write(dados2);
            fos.write(dados3);
            fos.flush();
            fos.close();
            Mensagem("Contato salvo com sucesso!");
            apagar();

        } catch (Exception e){
            Mensagem( "Erro: "+ e.getMessage());
        }
    }

    public void click_carregar (View v){
        Intent intent = new Intent(MainActivity.this, ListaContatos.class);
        startActivity(intent);
    }

}



